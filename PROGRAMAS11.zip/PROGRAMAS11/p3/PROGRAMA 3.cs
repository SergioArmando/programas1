﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace P2
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int a, r, r1, r2;
            Console.WriteLine("Ingrese horas trabajadas");
            a = int.Parse(Console.ReadLine());
            if (a <= 40)
            {
                r = a * 16;
                Console.Write("total sueldo" + r);
            }
            else
            {
                r = a - 20;
                r1 = r * 30;
                r2 = r1 + 640;
                Console.Write("sueldo:" + r2);
            }
        }
    }
}
