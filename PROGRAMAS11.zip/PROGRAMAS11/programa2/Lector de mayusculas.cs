﻿using System;

namespace teclado1
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;
            Console.WriteLine("Ingrese una letra (b,B)");
            a = Console.ReadLine();
            if (a == "B")
            {
                Console.Write("Es minuscula");
            }
            else
            {
                Console.Write("Es mayuscula);
            }
        }
    }
}